CREATE ALIAS PROCESS_BID FOR "pl.poznan.put.kacperwleklak.sql.rubis.RubisProcedures.processBid";
CREATE ALIAS BUY_NOW FOR "pl.poznan.put.kacperwleklak.sql.rubis.RubisProcedures.buyNow";
CREATE ALIAS PROCESS_COMMENT FOR "pl.poznan.put.kacperwleklak.sql.rubis.RubisProcedures.processComment";